const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

// 🎖 ROLES
const ROLES_TO_ADD = [
  '1365453730492977173', // Coscritto Role
  '1194299314382573582', // Permissions Role
  '1194299314198024212', // Designation Role
  '1365454194290724984', // Esercito Role
  '1365454243250704415', // Prima Role
  '1367496611940536451', // Main 7o Role
  '1194299314105745445', // Company Desgination Role
  '1370059101232435270', // 1o Battaglione Role
  '1367527053104124004', // 1o Depot Role
  '1367527136721633331', // 7o Social Role
  '1194299313971527720', // Awards Role
];
const ROLE_TO_REMOVE = '1365454187944607797';

const REQUIRED_ROLE_ID = '1367527159299706962';

// 📝 Log Channel
const INTAKE_CHANNEL_ID = '1195043147017891922';

// Roster Channel
const ROSTER_CHANNEL_ID = '1367498856371195945';

// 💬 Enlistment Message Template
const INTAKE_TEMPLATE = (user, recruiter, timezone) =>
  `<:7olinea:1336725919833919549>  Welcome to 7o Reggimento!
- <@${user.id}  
❓ TIP: Attend an event here, get promoted to Soldato!

https://discord.com/channels/1194299313665347654/1367498706659577896  | Look here when an event occurs! 🎪 
https://discord.com/channels/1194299313665347654/1367498576329969744  | Look here for the weekly schedule! 📰 
https://discord.com/channels/1194299313665347654/1367498297333383230  | Look here for the weekly promotions and drafts! 📌 
https://discord.com/channels/1194299313665347654/1367496955021758516  | Look here for organization and staff of 7°! <:GoldStar:1195054361588539392>

https://discord.gg/4FZjA8zHxb | Join this to join one of our many departments such as recruitment, flag staff, or the gfx department! <:JuanWithCrest:1200651114752778381>
**Recruited by: ${recruiter ?? 'No One'}** Timezone: ${timezone}`;

// ROSTER MESSAGE TEMPLATE
  const ROSTER_TEMPLATE = (user, recruiter) =>
    `<@${user.id}> - ${recruiter}`

module.exports = {
  data: new SlashCommandBuilder()
    .setName('enlist7o1')
    .setDescription('Enlists a user, assigns roles, and logs the enlistment.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)

    // ✅ Required options first
    .addUserOption(option =>
      option.setName('user')
        .setDescription('The person getting enlisted')
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName('timezone')
        .setDescription('Select the timezone of the enlisted user')
        .setRequired(true)
        .addChoices(
          { name: 'NA', value: 'NA' },
          { name: 'EU', value: 'EU' },
          { name: 'AS', value: 'AS' },
          { name: 'SA', value: 'SA' },
        )
    )

    // ✅ Optional option last
    .addUserOption(option =>
      option.setName('recruiter')
        .setDescription('The person who recruited them')
        .setRequired(false)
    ),

async execute(interaction) {
  const member = interaction.member;

  // 🔐 Role check: only users with the required role can use this command
  if (!member.roles.cache.has(REQUIRED_ROLE_ID)) {
    return interaction.reply({
      content: '❌ You do not have permission to use this command.',
      ephemeral: true
    });
  }

  const targetUser = interaction.options.getMember('user');
  const recruiterUser = interaction.options.getUser('recruiter');
  const timezone = interaction.options.getString('timezone');

  if (!targetUser) {
    return interaction.reply({ content: '❌ Could not find the target user.', ephemeral: true });
  }

  try {
    await interaction.deferReply({ ephemeral: true });

    // 🎖 Add enlistment roles
    for (const roleId of ROLES_TO_ADD) {
      await targetUser.roles.add(roleId);
    }

    // 🧹 Remove old role
    await targetUser.roles.remove(ROLE_TO_REMOVE);

    // 🧢 Add [RC] to nickname
    const currentNick = targetUser.nickname || targetUser.user.username;
    await targetUser.setNickname(`[RC] ${currentNick}`);

    // 📝 Send message to intake channel
    const logChannel = interaction.guild.channels.cache.get(INTAKE_CHANNEL_ID);
    if (logChannel) {
      await logChannel.send(INTAKE_TEMPLATE(targetUser, recruiterUser, timezone));
    } else {
      console.warn(`⚠️ Log channel with ID ${LOG_CHANNEL_ID} not found.`);
    }

    // Send message to roster channel
    const rosterChannel = interaction.guild.channels.cache.get(ROSTER_CHANNEL_ID);
    if (rosterChannel) {
      await rosterChannel.send(ROSTER_TEMPLATE(targetUser, recruiterUser));
    } else {
      console.warn(`⚠️ Roster channel with ID ${ROSTER_CHANNEL_ID} not found.`);
    }

    await interaction.editReply({ content: `✅ ${targetUser.user.tag} has been enlisted.` });
  } catch (error) {
    console.error(error);
    await interaction.editReply({ content: '❌ Something went wrong during enlistment.' });
  }
}
};